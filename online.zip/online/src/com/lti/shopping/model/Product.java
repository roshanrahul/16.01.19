
  package com.lti.shopping.model;
  
  import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
  
  @Entity 
  @Table(name="Product")
  public class Product implements Serializable{
  
	  private static final long serialVersionUID = 1L;
	  
	  @Id
	  @GeneratedValue(strategy = GenerationType.AUTO)
	  private int product_id;
	  
	
	/* @ManyToMany(cascade=CascadeType.ALL,mappedBy="list") */
	/*
	 * @JoinTable(name="Seller_product", joinColumns=
	 * {@JoinColumn(name="Product",referencedColumnName="product_id")},
	 * inverseJoinColumns=
	 * {@JoinColumn(name="Seller",referencedColumnName="sellId")})
	 */
	/* List<Seller> sellerList; */
	  
	  @ManyToOne
	 Seller seller;
	  
	  @ManyToOne
	  Category category;
	  
//	  public List<Seller> getSellerList() {
//			return sellerList;
//		}
//		public void setSellerList(List<Seller> sellerList) {
//			this.sellerList = sellerList;
//		}
		public Category getCategory() {
			return category;
		}
		public void setCategory(Category category) {
			this.category = category;
		}
	  
	  private String productName;
	  private String pdescription;
	  private int quantity;
	  private int price;
	  private byte[] image;
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getPdescription() {
		return pdescription;
	}
	public void setPdescription(String pdescription) {
		this.pdescription = pdescription;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Lob
    @Column(name = "Image", length = Integer.MAX_VALUE, nullable = true)
public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	//	
//	public Product(int product_id, List<Seller> sellerList, Category category, String productName, String pdescription,
//			int quantity, int price) {
//		super();
//		this.product_id = product_id;
//		//this.sellerList = sellerList;
//		this.category = category;
//		this.productName = productName;
//		this.pdescription = pdescription;
//		this.quantity = quantity;
//		this.price = price;
//	}
	public Product() {
		super();
	}
//	@Override
//	public String toString() {
//		return "Product [product_id=" + product_id + ", sellerList=" + sellerList + ", category=" + category
//				+ ", productName=" + productName + ", pdescription=" + pdescription + ", quantity=" + quantity
//				+ ", price=" + price + "]";
//	}
	  
	  
	  
	  
	  
  }
 