package com.lti.shopping.DAO;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.shopping.model.Product;

@Repository
public interface ProductDAO {

	Product get(int productId);
	List<Product> list();	
	void add(Product product);
	void update(Product product);
	void delete(int product);


}
