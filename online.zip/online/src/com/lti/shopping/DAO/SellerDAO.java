
  package com.lti.shopping.DAO;
  
  import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.lti.shopping.model.Seller;
@Repository
  public interface SellerDAO {
  
  boolean verifySeller(String email, String password);
  
  void addSeller(Seller s);
  
//  Seller getByEmail(String email);
  public List<Seller> listSeller();
  
  void removeSeller(int sellId);
  
  
  }
 