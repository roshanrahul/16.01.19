package com.lti.shopping.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lti.shopping.model.Seller;


@Service
public interface SellerService {
	
	 boolean verifySeller(String email, String password);
	  
	  void addSeller(Seller s);
	  
	 // Seller getByEmail(String email);
	  public List<Seller> listSeller();
	  
	  void removeSeller(int sellId);
}
