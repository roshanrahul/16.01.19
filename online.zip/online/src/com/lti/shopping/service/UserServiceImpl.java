package com.lti.shopping.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.shopping.DAO.UserDAO;
import com.lti.shopping.model.UserDetails;


@Service
@Transactional
public class UserServiceImpl implements UserService{
	
	
		private UserDAO userDAO;
	//setter method for personDao
		@Autowired
		public void setUserDao(UserDAO userDAO) {
			this.userDAO = userDAO;
		}
		@Override
		@Transactional
		public void addUser(UserDetails u) {
			this.userDAO.addUser(u);
		}

	
	  @Override 
	  @Transactional
	  public boolean verifyUser(String username, String password) {
	  return userDAO.verifyUser(username, password);
	  
	  }
	 
		@Override
		@Transactional
		public String getByEmail(String email) {
			 
			return this.getByEmail(email);
		}
	


}
