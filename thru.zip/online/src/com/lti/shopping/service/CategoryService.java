package com.lti.shopping.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lti.shopping.model.Category;
import com.lti.shopping.model.Seller;

@Service
public interface CategoryService {

	List<Category> listCategory();
  	Category get(int id); 
  	 Category getByName(String category_name);
}
