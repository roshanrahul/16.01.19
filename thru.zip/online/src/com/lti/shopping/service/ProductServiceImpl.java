package com.lti.shopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.shopping.DAO.ProductDAO;
import com.lti.shopping.model.Product;


@Service
@Transactional
public class ProductServiceImpl implements ProductService {

	
	 @Autowired
	private ProductDAO productDAO;
	


	public void setProductDAO(ProductDAO productDAO) {
		this.productDAO = productDAO;
	}

@Override
	public Product get(int productId) {
		 
		return productDAO.get(productId);
	}

	@Override
	public List<Product> list() {
		 
		return productDAO.list();
	}

	@Override
	public void add(Product product) {
		System.out.println("in service");
		this.productDAO.add(product);
		
	}

	@Override
	public void update(Product product) {
		this.productDAO.update(product);
		
	}

	@Override
	public void delete(int product) {
		this.productDAO.delete(product);
		
	}

	 

}
