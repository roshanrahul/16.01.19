package com.lti.shopping.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lti.shopping.model.Product;

@Service
public interface ProductService {


	Product get(int productId);
	List<Product> list();	
	void add(Product product);
	void update(Product product);
	void delete(int product);

}
