
  package com.lti.shopping.DAOImpl;
  
  import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import
  org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.shopping.DAO.SellerDAO;
import com.lti.shopping.model.Seller;
import com.lti.shopping.model.UserDetails;
  

@Repository("Seller")
  public class SellerDaoImpl implements SellerDAO{
  
 
	Transaction tx;
	
  private static final Logger logger =
  LoggerFactory.getLogger(SellerDaoImpl.class);
  
  private SessionFactory sessionFactory;
  
  @Autowired 
  public void setSessionFactory(SessionFactory sf) {
  this.sessionFactory = sf; }
  
  
  
  
  
  @Override
  public boolean verifySeller(String email, String password) 
  {
	  Session session = this.sessionFactory.openSession();
		 tx=session.beginTransaction();
	 
		 
		  String query="select email,password from Seller where email=:email and password=:password";

		  Query q=session.createQuery(query);
		  q.setString("email",email);
		  q.setString("password",password);
			  List<UserDetails> l=q.list();
			  if(l.size()==0)
			  {
			    return false;
			  }
		   
			 tx.commit(); 
		  session.close();
		  return true;

   
  }
  
  
  
  @Override public void addSeller(Seller s) {
	  Session session = this.sessionFactory.openSession();
		tx = session.beginTransaction();
		session.save(s);
		tx.commit();
		session.close();
		logger.info("User details saved successfully, User Details="+ s);
  
  }
  
  
  
  @Override public List<Seller> listSeller()
  {
	  Session session =this.sessionFactory.getCurrentSession(); 
	  List<Seller> sellerList =session.createQuery("from Seller").list(); 
	  for (Seller s : sellerList) {
		  logger.info("Seller List::" + s); 
	  	} 
	  return sellerList; 
}
  
  
  
  
  
  
  
  @Override public void removeSeller(int sellId) {
  
  Session session = this.sessionFactory.getCurrentSession();
  Seller s =(Seller) session.load(Seller.class, new Integer(sellId));
  if (null != s) 
  {
  session.delete(s); 
  
  }else 
  { 
	  logger.error("Person NOT deleted, with person Id=" +s);
  }
  logger.info("Person deleted successfully, person details=" + s); }





	
	  @Override public Seller getByEmail(String email)
	  { 
		  Integer sell=0;
		 // Session session = this.sessionFactory.getCurrentSession();
		 // String selectQuery ="select sellId from Seller WHERE email =:email";
		  
	  
	//  Transaction trns = null; 
	  Session session = this.sessionFactory.openSession();
	  tx = session.beginTransaction(); 
	  
	  System.out.println(email); 
	  Query query =session.createQuery("from Seller s  where s.email=:email");
	 query.setString("email", email);
	 
	 List<Seller> sellerlist=query.list();
	 
	 tx.commit();
	 session.close();
	 if(sellerlist.size()>0) {
		 System.out.println(sellerlist);
		 return sellerlist.get(0);
	 }else
	 {
		 return null;
	 }
	 
////	  List qlist=query.list();
////      Iterator iterator = ((Query) qlist).iterate();
////    
////    while(iterator.hasNext())
////    {
////    	sell =  (Integer)iterator.next();
////   	 
////    }
////    System.out.println(sell);
////	  query.setParameter("email", email);
////	  System.out.println("in impl1"); 
//	  
//	  Seller s = (Seller) session.load(Seller.class, new Integer(query));
//	  System.out.println("in impl2"); 
//	  System.out.println(s);
//	  
//	  
//	  return s; }
	 
  
  }
}
  
  
 