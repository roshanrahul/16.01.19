package com.lti.shopping.controller;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.lti.shopping.model.Product;
import com.lti.shopping.model.Seller;
/*import com.lti.shopping.DAO.CategoryDAO;
import com.lti.shopping.model.Category;*/
import com.lti.shopping.model.UserDetails;
import com.lti.shopping.service.ProductService;
import com.lti.shopping.service.SellerService;
import com.lti.shopping.service.UserService;

@Controller
@SessionAttributes("seller")
public class PageController {

	private UserService userService;

	private SellerService sellerService;

	private ProductService productService;

	@Autowired
	public void setProductService(ProductService productService) {
		this.productService = productService;
	}

	@Autowired
	public void setSellerService(SellerService sellerService) {
		this.sellerService = sellerService;
	}

	@Autowired
	public void setUserService(UserService ps) {
		this.userService = ps;
	}

	@Autowired
	/* private CategoryDAO categoryDAO; */
//
	
	   @RequestMapping(value = { "/" }) 
	public ModelAndView goHome() { 
	  ModelAndView mv = new ModelAndView("index.jsp");
	  return mv; 
	  }
	 
	
//	  @RequestMapping(value = { "/" })
//	public String goHome(Model model,HttpSession
//	  session)
//	{
//		Product product=new Product();
//		productService.getProduct();
//	  return "redirect:/index";
//	  }
	 

	
	// for user

	@RequestMapping(value = "/login")
	public String login(Model model) {
		 model.addAttribute("userdetails",new UserDetails());
		return "login";
	}

	
	@RequestMapping(value = "/loginverification", method = RequestMethod.POST)
	public String LoginValidation(@ModelAttribute ("userdetails")
									@Valid UserDetails u, 
									BindingResult result, HttpServletRequest req, HttpSession session,Model model) {
		String email = req.getParameter("email");
		String password = req.getParameter("password");

	 

		if (email.equals("admin@gmail.com") && password.equals("admin"))

		{
			return "admin";

		} else if (userService.verifyUser(email, password)) {
			
			session.setAttribute("email",u.getEmail());
			return "redirect:/";
		} else
			return "login";

	}

	@RequestMapping(value = "/register")
	public String register(Model m) {
		m.addAttribute("user", new UserDetails());
		return "register";
	}

	@RequestMapping(value = "/register/add", method = RequestMethod.POST)
	public String addUser(@ModelAttribute("user") UserDetails u, BindingResult result, Model model) {
		try {
			if (!result.hasErrors()) {
				if (u.getId() == null || u.getId() == 0) {

					this.userService.addUser(u);
				}

				return "redirect:/login";
			}
		} catch (Exception e) {

			e.printStackTrace();
		}

		return "register";
	}

	// for seller

	@RequestMapping(value = "/seller_login")
	public ModelAndView sellerLogin() {
		ModelAndView mv = new ModelAndView("seller_login");
		return mv;
	}

	@RequestMapping(value = "/seller_register")
	public String registerSeller(Model m) {

		m.addAttribute("seller", new Seller());
		return "seller_register";
	}

	@RequestMapping(value = "/selleradd", method = RequestMethod.POST)
	public String addSeller(@ModelAttribute("seller") Seller s, BindingResult result, Model model) {

		try {
			if (!result.hasErrors()) {
				if (s.getSellId() == null || s.getSellId() == 0) {

					this.sellerService.addSeller(s);
				}

				return "redirect:/seller_login";
			}
		} catch (Exception e) {

			e.printStackTrace();
		}

		return "seller_register";
	}

	@RequestMapping(value = "/sellerverification", method = RequestMethod.POST)
	public String SellerValidation(Model model, HttpServletRequest req, HttpSession session) {
		String email = req.getParameter("email");
		String password = req.getParameter("password");

//		System.out.println("this is password" + email);
//		System.out.println("this is password" + password);

		if (sellerService.verifySeller(email, password)) {
			
			
			
			 Seller sellerobj = sellerService.getByEmail(email);
			 Category catobj=categoryService.get
			 System.out.println("hello mayuri ");
			 session.setAttribute("seller",sellerobj);
			
			 
			System.out.println("hello");
			
			model.addAttribute("product", new Product());
			//model.setAttribute("",s);
			return "sellerdashboard";
		} else
			return "seller_login";

	}

	// for product

	@RequestMapping(value = "/productadd", method = RequestMethod.POST)
	public String addProduct(@ModelAttribute("product") Product p, BindingResult result, Model model, HttpSession ses,Seller seller) {

     Seller s=(Seller) ses.getAttribute("seller");
		p.setSeller(s);
		this.productService.add(p);
		return "added";

	}

	
	@RequestMapping(value = "/logout")
	public String logout(HttpSession session) {
		session.invalidate();
	   return "redirect:/";
	}

	/*
	 * @RequestMapping(value="/productupd" ,method = RequestMethod.POST) public
	 * String updProduct( Model model,HttpSession ses,@PathVariable("product_id")
	 * int product_id) { { Product productObj =
	 * this.productService.getProductById(product_id); model.addAttribute("product",
	 * productObj); List<Product> productListObj = this.productService.list();
	 * model.addAttribute("listProduct", productListObj); return "product";// view
	 * name
	 */

	@RequestMapping(value = "/productdel", method = RequestMethod.POST)
	public String delProduct(@ModelAttribute("product") Product p, BindingResult result, Model model, HttpSession ses) {

		/*
		 * System.out.println("mayuri"); Seller seller =
		 * (Seller)ses.getAttribute("seller"); ArrayList<Product> prdlist=new
		 * ArrayList<Product>(); seller.setList(prdlist); prdlist.add(p);
		 */
		this.productService.add(p);
		return "added";

	}
//	@RequestMapping(value="/seller_login")
//	public ModelAndView seller() {
//		ModelAndView mv=new ModelAndView("seller_login");
//		mv.addObject("title","Sell");
//		mv.addObject("userClickSell",true);
//		return mv;
//	}
//	
//	@RequestMapping(value="/registerPage",method=RequestMethod.POST)
//	public String validateregistrationPage(@Valid @ModelAttribute("authuser") 
//	User authuser ,BindingResult bindingResult,Model model,HttpServletRequest req)
//	{
//		
//		String view="";
//	if(bindingResult.hasErrors())
//	{
//		view="success";
//		return view;
//	}
//	else
//	{
//		String username=req.getParameter("userEmail");
//		String password=req.getParameter("password");
//	
//	
//		userService.addUser(authuser);
//		
//		view="success";
//		return view;
//		
//	}
//	}

//	@RequestMapping(value="/Television")
//	public ModelAndView Television() {
//		ModelAndView mv=new ModelAndView("Products");
//		mv.addObject("title","Category TV");
//		mv.addObject("userClickTelevision",true);
//		return mv;
//	}
//	// method to load products based on categories
//	@RequestMapping(value="/show/all/products")
//	public ModelAndView showAllPoducts() {
//		ModelAndView mv=new ModelAndView("page");
//		mv.addObject("title","All Products");
//		
//		//pass list of categories
//		mv.addObject("categories",categoryDAO.list());
//		mv.addObject("userClickAllProducts",true);
//		return mv;
//	}
//	
//	@RequestMapping(value="/show/{id}/products")
//	public ModelAndView showCategoryPoducts(@PathVariable("id") int id) {
//		ModelAndView mv=new ModelAndView("page");
//		
//		//categorydao to fetch a single category
//		Category category=null;
//		category=categoryDAO.get(id);
//		mv.addObject("title","All Products");
//		
//		//pass list of categories
//		mv.addObject("categories",categoryDAO.list());
//		mv.addObject("userClickAllProducts",true);
//		return mv;
//	}

}
